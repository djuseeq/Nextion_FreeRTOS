/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "Nextion_HMI.h"
#include "stdlib.h" // for rand() function
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
Nextion_Object_t txtObj1, txtObj2, intObj1, slider1Obj, gauge1Obj, prgressBarObj, btn1Obj;
/* USER CODE END Variables */
/* Definitions for Display */
osThreadId_t DisplayHandle;
const osThreadAttr_t Display_attributes = {
  .name = "Display",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 128 * 4
};
/* Definitions for Blinky */
osThreadId_t BlinkyHandle;
const osThreadAttr_t Blinky_attributes = {
  .name = "Blinky",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 128 * 4
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
void initObjects(void);
void sendBack(void);
void changeSpeed(void);
void askSliderValue(void);
void btnPress(void);
/* USER CODE END FunctionPrototypes */

void StartDisplayTask(void *argument);
void StartTaskBlinky(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
	initObjects();
  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of Display */
  DisplayHandle = osThreadNew(StartDisplayTask, NULL, &Display_attributes);

  /* creation of Blinky */
  BlinkyHandle = osThreadNew(StartTaskBlinky, NULL, &Blinky_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDisplayTask */
/**
  * @brief  Function implementing the Display thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDisplayTask */
void StartDisplayTask(void *argument)
{
  /* USER CODE BEGIN StartDisplayTask */
	uint8_t progressBarVal = 0;
  /* Infinite loop */
  for(;;)
  {
	  if(nextionHMI_h.hmiStatus == COMP_IDLE){
		  NxHmi_SetIntValue(&prgressBarObj, progressBarVal);
		  if(progressBarVal++ == 100){
			  progressBarVal = 0;
		  }
	  }
    osDelay(10);
  }
  /* USER CODE END StartDisplayTask */
}

/* USER CODE BEGIN Header_StartTaskBlinky */
/**
* @brief Function implementing the Blinky thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTaskBlinky */
void StartTaskBlinky(void *argument)
{
  /* USER CODE BEGIN StartTaskBlinky */
  /* Infinite loop */
  for(;;)
  {
	  HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
    osDelay(500);
  }
  /* USER CODE END StartTaskBlinky */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
void initObjects(void){
	txtObj1.Name = "t0";
	txtObj1.Component_ID = 1;
	txtObj1.Page_ID = 0;
	txtObj1.dataType = OBJ_TYPE_TXT;
	txtObj1.PressCallback = &sendBack;
	txtObj1.ReleaseCallback = NULL;
	NxHmi_AddObject(&txtObj1);


	txtObj2.Name = "t1";
	txtObj2.Component_ID = 4;
	txtObj2.Page_ID = 0;
	txtObj2.PressCallback = NULL;
	txtObj2.ReleaseCallback = NULL;
	NxHmi_AddObject(&txtObj2);

	intObj1.Name = "n0";
	intObj1.Page_ID = 0;
	intObj1.Component_ID = 2;
	intObj1.PressCallback = &changeSpeed;
	intObj1.ReleaseCallback = NULL;
	NxHmi_AddObject(&intObj1);

	slider1Obj.Name = "h0";
	slider1Obj.Page_ID = 0;
	slider1Obj.Component_ID = 7;
	slider1Obj.dataType = OBJ_TYPE_INT;
	slider1Obj.PressCallback = NULL;
	slider1Obj.ReleaseCallback = &askSliderValue;
	NxHmi_AddObject(&slider1Obj);

	gauge1Obj.Name = "z0";
	gauge1Obj.Page_ID = 0;
	gauge1Obj.Component_ID = 5;
	gauge1Obj.dataType = OBJ_TYPE_INT;
	gauge1Obj.PressCallback = NULL;
	gauge1Obj.ReleaseCallback = NULL;
	NxHmi_AddObject(&slider1Obj);

	prgressBarObj.Name = "j0";
	prgressBarObj.Page_ID = 0;
	prgressBarObj.Component_ID = 6;
	prgressBarObj.dataType = OBJ_TYPE_INT;
	prgressBarObj.PressCallback = NULL;
	prgressBarObj.ReleaseCallback = NULL;
	NxHmi_AddObject(&prgressBarObj);

	btn1Obj.Name = "bt0";
	btn1Obj.Page_ID = 0;
	btn1Obj.Component_ID = 3;
	btn1Obj.dataType = OBJ_TYPE_INT;
	btn1Obj.PressCallback = &btnPress;
	btn1Obj.ReleaseCallback = NULL;
	NxHmi_AddObject(&btn1Obj);
}

void sendBack(void){
	uint16_t rndszam = 0;
	//SEGGER_SYSVIEW_Start();
	  NxHmi_SetText(&txtObj1, "Sok");

	  rndszam = (10 + rand() ) % 90;
	  NxHmi_SetIntValue(&intObj1, rndszam);


	  NxHmi_SetBcoColour(&txtObj1, rand() % 65535);
	  NxHmi_SetBacklight(50, SET_TEMPORARY);
}

void btnPress(void){
	uint32_t tmpInt = NxHmi_GetObjValue(&btn1Obj);
	if(tmpInt) {
		NxHmi_SetBcoColour(&gauge1Obj, 31); // blue
	} else {
		NxHmi_SetBcoColour(&gauge1Obj, 2016); // green
	}
}

void changeSpeed(void){
	//NxHmi_Baud_Rate(9600, 0);
}

void askSliderValue(void){
	int32_t tempValue = NxHmi_GetObjValue(&slider1Obj);
	if(tempValue != -1){
		NxHmi_SetIntValue(&gauge1Obj, MAP_NR(tempValue, 0, 100, 0, 360));
		char bufff[10];
		sprintf(bufff, "%ld", tempValue);

		NxHmi_SetText(&txtObj2, bufff);
	}


}
/* USER CODE END Application */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
